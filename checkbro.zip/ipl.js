import { Link , React } from 'react'
import home from './images/home.jph'

function Ipl(){
    return(
        <div>
            <table>
                <tr>
                    <td>
                        <Link to="/"><img src={home} width="50" height="50"/></Link>
                    </td>
                    <td colspan="2">
                        <Link to="/options"><input type="button"  value="options"></input></Link>
                    </td>
                    <td>
                        
                    </td>
                </tr>
            </table>
        </div>
    )
}